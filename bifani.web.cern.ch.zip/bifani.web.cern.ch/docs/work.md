<!-- Piwik --> 
<script type="text/javascript"> 
var pkBaseURL = (("https:" == document.location.protocol) ? "https://piwik.web.cern.ch/" : "http://piwik.web.cern.ch/"); 
document.write(unescape("%3Cscript src='" + pkBaseURL + "piwik.js' type='text/javascript'%3E%3C/script%3E")); 
</script><script type="text/javascript"> 
try { 
var piwikTracker = Piwik.getTracker(pkBaseURL + "piwik.php", 152); 
piwikTracker.trackPageView(); 
piwikTracker.enableLinkTracking(); 
} catch( err ) {} 
</script><noscript><p><img src="http://piwik.web.cern.ch/piwik.php?idsite=152" style="border:0" alt="" /></p></noscript> 
<!-- End Piwik Tracking Code -->

### Meetings

[<img src="../_images/indico.png" height="50">](https://indico.cern.ch/user/4548/dashboard/)

<br>
[<img src="../_images/lhcb.png" height="50">](http://lhcb-public.web.cern.ch/lhcb-public/Welcome.html)

- **EWP Meeting**: 2 May 2018, [www](https://indico.cern.ch/event/724519/)

- **A&S Week**: 26 January 2018, [www](https://indico.cern.ch/event/689674/)

- **Approval Meeting**: 31 March 2017, [www](https://indico.cern.ch/event/627276/)

- **Tuesday Meeting**: 14 March 2017, [www](https://indico.cern.ch/event/623467/)

- **LHCb Week**: 2 March 2017, [www](https://indico.cern.ch/event/607443/)

- **RD Meeting**: 18 January 2017, [www](https://indico.cern.ch/event/604838/)

- **EWP Meeting**: 17 August 2016, [www](https://indico.cern.ch/event/562869/)

- **EWP Meeting**: 20 July 2016, [www](https://indico.cern.ch/event/557249/)

- **A&S Week**: 14 July 2016, [www](https://indico.cern.ch/event/442261/)

- **RD Meeting**: 1 June 2016, [www](https://indico.cern.ch/event/489957/)

- **PID Meeting**: 13 April 2016, [www](https://indico.cern.ch/event/518431/)

- **EW Meeting**: 18 Febuary 2016, [www](https://indico.cern.ch/event/496349/)

- **PID Meeting**: 17 Febuary 2016, [www](https://indico.cern.ch/event/496906/)

- **PID Meeting**: 3 Febuary 2016, [www](https://indico.cern.ch/event/491966/)

- **RD Meeting**: 20 January 2016, [www](https://indico.cern.ch/event/485379/)

- **RD Meeting**: 2 December 2015, [www](https://indico.cern.ch/event/405161/)

- **RD Meeting**: 2 October 2015, [www](https://indico.cern.ch/event/405155/)

- **Approval Meeting**: 12 October 2015, [www](https://indico.cern.ch/event/440733/)

- **EW Meeting**: 6 August 2015, [www](https://indico.cern.ch/event/437132/)

- **EWP Meeting**: 5 August 2015, [www](https://indico.cern.ch/event/407478/)

- **EW Meeting**: 5 March 2015, [www](https://indico.cern.ch/event/378147/)

- **EW Meeting**: 5 February 2015, [www](https://indico.cern.ch/event/371338/)

- **EW Meeting**: 2 January 2015, [www](https://indico.cern.ch/event/367601/)

- **EW Meeting**: 8 January 2015, [www](https://indico.cern.ch/event/361989/)

- **RD Meeting**: 10 December 2014, [www](https://indico.cern.ch/event/268928/)

- **EW Meeting**: 27 November 2014, [www](https://indico.cern.ch/event/354977/)

- **EW Meeting**: 24 October 2014, [www](https://indico.cern.ch/event/347949/)

- **Approval Meeting**: 10 June 2014, [www](https://indico.cern.ch/event/237882/)

- **QEE Meeting**: 8 May 2014, [www](https://indico.cern.ch/event/317139/)

- **EW Meeting**: 2 May 2014, [www](https://indico.cern.ch/event/316349/)

- **EW Meeting**: 7 February 2014, [www](https://indico.cern.ch/event/299631/)

- **EW Meeting**: 6 December 2013, [www](https://indico.cern.ch/event/286709/)

- **EW Meeting**: 8 November 2013, [www](https://indico.cern.ch/event/281866/)

- **EW Meeting**: 2 August 2013, [www](https://indico.cern.ch/event/268206/)

- **LHCb Week**: 7 June 2013, [www](https://indico.cern.ch/event/251037/)

- **T&A Meeting**: 7 March 2013, [www](https://indico.cern.ch/event/223867/)

- **QEE Meeting**: 2 February 2013, [www](https://indico.cern.ch/event/236169/)

- **EW Meeting**: 7 December 2012, [www](https://indico.cern.ch/event/221011/)

- **T&A Meeting**: 6 December 2012, [www](https://indico.cern.ch/event/208818/)

- **EW Meeting**: 9 November 2012, [www](https://indico.cern.ch/event/216565/)

- **EW Meeting**: 12 October 2012, [www](https://indico.cern.ch/event/212199/)

- **EW Meeting**: 20 July 2012, [www](https://indico.cern.ch/event/201056/)

- **EW Meeting**: 4 May 2012, [www](https://indico.cern.ch/event/189574/)

- **EW Meeting**: 13 April 2012, [www](https://indico.cern.ch/event/186453/)

- **EW Meeting**: 2 October 2011, [www](https://indico.cern.ch/event/159430/)

- **EW Meeting**: 14 October 2011, [www](https://indico.cern.ch/event/158678/)

- **EW Meeting**: 7 October 2011, [www](https://indico.cern.ch/event/157396/)

- **EW Meeting**: 2 September 2011, [www](https://indico.cern.ch/event/155850/)

- **EW Meeting**: 2 September 2011, [www](https://indico.cern.ch/event/152944/)

- **EW Meeting**: 10 June 2011, [www](https://indico.cern.ch/event/142579/)

- **EW Meeting**: 20 May 2011, [www](https://indico.cern.ch/event/139288/)

- **EW Meeting**: 1 April 2011, [www](https://indico.cern.ch/event/133162/)

- **EW Meeting**: 4 March 2011, [www](https://indico.cern.ch/event/129281/)

- **EW Meeting**: 10 February 2011, [www](https://indico.cern.ch/event/126508/)

- **EW Meeting**: 28 January 2011, [www](https://indico.cern.ch/event/124318/)

- **EW Meeting**: 2 January 2011, [www](https://indico.cern.ch/event/123078/)

- **EW Meeting**: 26 November 2010, [www](https://indico.cern.ch/event/114590/)

- **EW Meeting**: 19 November 2010, [www](https://indico.cern.ch/event/113827/)

- **EW Meeting**: 5 November 2010, [www](https://indico.cern.ch/event/112563/)

- **EW Meeting**: 29 October 2010, [www](https://indico.cern.ch/event/111863/)

- **EW Meeting**: 22 October 2010, [www](https://indico.cern.ch/event/110969/)

- **EW Meeting**: 15 October 2010, [www](https://indico.cern.ch/event/110539/)

- **EW Meeting**: 24 September 2010, [www](https://indico.cern.ch/event/108139/)

- **EW Meeting**: 16 July 2010, [www](https://indico.cern.ch/event/101492/)

- **EW Meeting**: 18 June 2010, [www](https://indico.cern.ch/event/98611/)

- **EW Meeting**: 11 June 2010, [www](https://indico.cern.ch/event/97852/)

- **Tuesday Meeting**: 1 June 2010, [www](https://indico.cern.ch/event/92702/)

- **EW Meeting**: 2 May 2010, [www](https://indico.cern.ch/event/95299/)

- **EW Meeting**: 7 May 2010, [www](https://indico.cern.ch/event/93851/)

- **EW Meeting**: 2 April 2010, [www](https://indico.cern.ch/event/92035/)

<br>
[<img src="../_images/na48.gif" height="50">](http://na48.web.cern.ch/NA48/NA48-2/NA48_2.html)
&nbsp;&nbsp;&nbsp;
[<img src="../_images/na62.gif" height="50">](http://na62.web.cern.ch/na62/)

- **Analysis Meeting**: 30 October 2009, [www](https://indico.cern.ch/event/71036/)

- **Collaboration Meeting**: 1 - 4 September 2009, [www](http://na62meeting.na.infn.it/)

- **Weekly Meeting**: 13 August 2009, [www](https://indico.cern.ch/event/66120/)

- **Physics Sensitivity Meeting**: 1 April 2009, [www](https://indico.cern.ch/event/55997/)

- **Software and Computing Meeting**: 29 January 2009, [www](https://indico.cern.ch/event/50512/)

- **Analysis Meeting**: 29 January 2009, [www](https://indico.cern.ch/event/49362/)

- **Weekly Meeting**: 8 January 2009, [www](https://indico.cern.ch/event/48811/)

- **Weekly Meeting**: 18 December 2008, [www](https://indico.cern.ch/event/47645/)

- **Analysis Meeting**: 30 January 2008, [www](https://indico.cern.ch/event/27877/)

- **Collaboration Meeting**: 12 December 2007, [www](https://indico.cern.ch/event/25023/)

- **Analysis Meeting**: 12 June 2007, [www](https://indico.cern.ch/event/18586/)

- **Weekly Meeting**: 7 June 2007, [www](https://indico.cern.ch/event/17180/)

- **Collaboration Meeting**: 18 April 2007, [www](https://indico.cern.ch/event/14876/)

- **Analysis Meeting**: 1 February 2007, [www](https://indico.cern.ch/event/11437/)

- **Collaboration Meeting**: 4 - 10 September 2006, [www](http://na48.web.cern.ch/NA48/NA48-2/Dubna_meeting/na48collab.html/)

- **GTK Meeting**: 4 July 2006, [www](https://indico.cern.ch/event/4263/)

- **GTK Meeting**: 3 April 2006, [www](https://indico.cern.ch/event/1420/)

- **GTK Meeting**: 2 November 2005, [www](https://indico.cern.ch/event/a057009/)

- **Analysis Meeting**: 6 May 2004, [www](https://indico.cern.ch/event/a041464/)

<br>
### Documents

[<img src="../_images/cds.png" height="50">](http://cdsweb.cern.ch/search?ln=en&as=1&cc=LHCb&m1=a&p1=BIFANI&f1=author&op1=a&m2=a&p2=&f2=&op2=a&m3=a&p3=&f3=&action_search=Search&c=LHCb+Analysis+Notes&c=LHCb+Conference+Contributions&c=LHCb+Conference+Proceedings&c=LHCb+Internal+Notes&c=LHCb+Notes&c=LHCb+Talks&sf=&so=a&rm=&rg=25&sc=1&of=hb)
&nbsp;&nbsp;&nbsp;
[<img src="../_images/cernsearch.png" height="50">](https://search.cern.ch/Pages/IndicoResults.aspx?k=bifani&v1=-write#Default=%7B%22k%22%3A%22bifani%22%2C%22o%22%3A%5B%7B%22d%22%3A1%2C%22p%22%3A%22StartDate%22%7D%5D%7D)
