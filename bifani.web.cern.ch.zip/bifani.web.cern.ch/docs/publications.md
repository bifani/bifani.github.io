### Publications

<script type="text/javascript">
<!--
var arxiv_authorid = "https://arxiv.org/a/0000-0001-7072-4854";
var arxiv_authorid = "https://arxiv.org/a/bifani_s_1";
var arxiv_format = "arxiv";
var arxiv_max_entries = 0;
var arxiv_includeTitle = 0;
var arxiv_includeSummary = 0;
//--></script>
<style type="text/css">
div.arxivfeed {margin-bottom: 5px; width:300px;}
</style>
<script type="text/javascript" src="https://arxiv.org/js/myarticles.js"></script> 
<div id="arxivfeed"></div>
